import random
import Tests

import math

def generate_initial_population(number_of_ants):

    ant = Tests.Ant()
    ant.random_steering()

    direction = [Tests]
